import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/shared/product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  ProductsList: any = [];
  updateProductForm: FormGroup;

  ngOnInit() {
    this.updateForm();
  }

  constructor(
    private actRoute: ActivatedRoute,
    public productService: ProductService,
    public fb: FormBuilder,
    private ngZone: NgZone,
    private router: Router
  ) {
    var id = this.actRoute.snapshot.paramMap.get('id');
    this.productService.GetIssue(id).subscribe((data) => {
      this.updateProductForm = this.fb.group({
        issue_name: [data.product_name],
        issue_message: [data.product_name],
      });
    });
  }

  updateForm() {
    this.updateProductForm = this.fb.group({
      product_name: [''],
      product_unit: [''],
    });
  }

  submitForm() {
    var id = this.actRoute.snapshot.paramMap.get('id');
    this.productService
      .UpdateBug(id, this.updateProductForm.value)
      .subscribe((res) => {
        this.ngZone.run(() => this.router.navigateByUrl('/product-list'));
      });
  }

}
