import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/shared/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  productForm: FormGroup;
  ProductArr: any = [];

  ngOnInit() {
    this.addProduct();
  }

  constructor(
    public fb: FormBuilder,
    private ngZone: NgZone,
    private router: Router,
    public productService: ProductService
  ) {}

  addProduct() {
    this.productForm = this.fb.group({
      product_name: [''],
      product_unit: [''],
    });
  }

  submitForm() {
    this.productService.CreateBug(this.productForm.value).subscribe((res) => {
      console.log('Producto añadido');
      this.ngZone.run(() => this.router.navigateByUrl('/product-list'));
    });
  }

}
