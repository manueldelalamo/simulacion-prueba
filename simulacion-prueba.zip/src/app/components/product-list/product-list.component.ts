import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/shared/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  ProductsList: any = [];

  ngOnInit() {
    this.loadEmployees();
  }

  constructor(public productService: ProductService) {}

  loadEmployees() {
    return this.productService.GetIssues().subscribe((data: {}) => {
      this.ProductsList = data;
    });
  }

  deleteProduct(data) {
    var index = (index = this.ProductsList.map((x) => {
      return x.product_name;
    }).indexOf(data.product_name));
    return this.productService.DeleteBug(data.id).subscribe((res) => {
      this.ProductsList.splice(index, 1);
      console.log('Producto eliminado');
    });
  }

}
