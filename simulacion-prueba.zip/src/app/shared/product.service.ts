import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from './product';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  // Base url
  baseurl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  // POST
  CreateBug(data): Observable<Product> {
    return this.http
      .post<Product>(
        this.baseurl + '/producttracking/',
        JSON.stringify(data),
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET
  GetIssue(id): Observable<Product> {
    return this.http
      .get<Product>(this.baseurl + '/producttracking/' + id)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET
  GetIssues(): Observable<Product> {
    return this.http
      .get<Product>(this.baseurl + '/producttracking/')
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // PUT
  UpdateBug(id, data): Observable<Product> {
    return this.http
      .put<Product>(
        this.baseurl + '/producttracking/' + id,
        JSON.stringify(data),
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // DELETE
  DeleteBug(id) {
    return this.http
      .delete<Product>(this.baseurl + '/producttracking/' + id, this.httpOptions)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(() => {
      return errorMessage;
    });
  }
}
