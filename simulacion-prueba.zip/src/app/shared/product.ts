export class Product {
    id: string;
    product_name: string;
    product_unit: number;
  }
  